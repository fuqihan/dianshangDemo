<template>
<div class="navigation">

</div>
</template>

<script>
export default{}
</script>

<style lang="less">
.navigation{
  width: 30px;
  height: 100%;
  background: black;
  position: fixed;
  top: 0;
  right: 0;
  z-index: 99;
}
</style>
