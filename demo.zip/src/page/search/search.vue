<template>
  <div class="search">
    <div class="search-header">
      <div class="search-header-top">
       <span class="focus"><i class="iconfont icon-wodedingdan"
                              style="font-size: 20px; margin-right: 5px"></i>商品分类</span>
      </div>
      <div class="search-header-option">

      </div>
    </div>
  </div>
</template>

<script>
  export default{}
</script>

<style lang="less">
  @import "../../style/my";

  .search {
    .search-header {
      .search-header-top {
        height: 45px;
        width: 100%;
        border-bottom: 2px solid @index-ls-color;
        .focus {
          display: inline-block;
          margin-left: @index-center-left-margin-left;
          width: @index-center-left-width;
          height: 100%;
          color: white;
          background: @index-ls-color;
          .flex-center();
        }
      }
    }
  }
</style>
