/**
 * Created by fuqihan on 2017/4/8.
 */
export const NAVIGATION_INFO_TRUE = 'NAVIGATION_INFO_TRUE'
export const NAVIGATION_INFO_FALSE = 'NAVIGATION_INFO_FALSE'
