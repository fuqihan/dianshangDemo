// 引用图片路径
let a = require('./img/home/aa.jpg')
let b = require('./img/home/bb.jpg')
let c = require('./img/home/cc.jpg')
let d = require('./img/home/dd.jpg')
let e = require('./img/home/ee.jpg')
let f = require('./img/home/ff.jpg')
let qr = require('./img/code/pr.jpg')
let logo = require('./img/code/logo.png')


// 导出图片
module.exports = {
  a,
  b,
  c,
  d,
  e,
  f,
  qr,
  logo
}
